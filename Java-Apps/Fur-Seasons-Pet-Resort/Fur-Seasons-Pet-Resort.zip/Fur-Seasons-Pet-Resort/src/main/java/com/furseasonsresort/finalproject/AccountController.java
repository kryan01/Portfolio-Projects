
package com.furseasonsresort.semesterproject;

public class AccountController
{

    public static void showAccountScene()
    {
        if (!UserManager.isLoggedIn())
        {
            LoginController.showLoginWindow();
        }
        else
        {
            UserAccountController.showUserAccountWindow(UserManager.getCurrentUser());
        }
    }
}
