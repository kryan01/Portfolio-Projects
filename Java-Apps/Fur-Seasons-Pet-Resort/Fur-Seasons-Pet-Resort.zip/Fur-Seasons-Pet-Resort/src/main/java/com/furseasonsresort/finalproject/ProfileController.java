package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ProfileController
{

    public static void showProfileWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Profile & Pets");

        Label header = new Label("Your Profile & Pets");
        header.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");

        // username display
        String username = UserManager.getCurrentUser();
        Label userLabel = new Label("Username: " + (username != null ? username : "Guest"));
        userLabel.setStyle("-fx-font-size:14px;");

        // pets list
        Label petsHeader = new Label("Your Pets:");
        petsHeader.setStyle("-fx-font-size:14px; -fx-underline:true;");
        ListView<Pet> petsList = new ListView<>();
        ObservableList<Pet> pets = UserManager.getPets();
        petsList.setItems(pets);
        petsList.setPrefHeight(150);

        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> stage.close());

        // layout
        VBox root = new VBox(10,
                header,
                userLabel,
                petsHeader,
                petsList,
                backBtn
        );
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color:#fcefdb;");

        stage.setScene(new Scene(root, 350, 350));
        stage.show();
    }
}
