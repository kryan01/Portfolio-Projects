package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class BoardingController
{
    // single‑arg overload
    public void showBoardingWindow(String defaultPetType)
    {
        showBoardingWindow(defaultPetType, null);
    }

    public void showBoardingWindow(String defaultPetType, String defaultDuration)
    {
        Stage stage = new Stage();
        stage.setTitle("Book With Us");

        // pet type
        ToggleGroup petToggle = new ToggleGroup();
        RadioButton catRb = new RadioButton("Cat");
        RadioButton dogRb = new RadioButton("Dog");
        catRb.setToggleGroup(petToggle);
        dogRb.setToggleGroup(petToggle);
        if ("Dog".equalsIgnoreCase(defaultPetType)) dogRb.setSelected(true);
        else catRb.setSelected(true);

        HBox typeBox = new HBox(10, new Label("Pet Type:"), catRb, dogRb);
        typeBox.setAlignment(Pos.CENTER_LEFT);

        // client dropdown
        ObservableList<Pet> pets = UserManager.getPets();
        ComboBox<Pet> clientCombo = new ComboBox<>(pets);
        clientCombo.setPromptText("Select Client");
        clientCombo.setConverter(new StringConverter<>()

        {
            @Override public String toString(Pet p)
            {
                return p == null ? "" : p.getName();
            }
            @Override public Pet fromString(String s)
            {
                return null;
            }
        });
        HBox headerBox = new HBox();
        headerBox.setPadding(new Insets(0, 0, 10, 0));
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.getChildren().addAll(typeBox, new Region(), new Label("Client:"), clientCombo);
        HBox.setHgrow(headerBox.getChildren().get(1), Priority.ALWAYS);

        // service dropdown
        Label svcLbl = new Label("Service:");
        ComboBox<String> svcCombo = new ComboBox<>();
        svcCombo.getItems().addAll("Daycare", "Boarding");
        svcCombo.setValue(defaultDuration == null ? "Boarding" : "Daycare");
        HBox svcBox = new HBox(10, svcLbl, svcCombo);
        svcBox.setAlignment(Pos.CENTER_LEFT);

        // duration (Daycare only)
        Label durLbl = new Label("Duration:");
        ComboBox<String> durationCombo = new ComboBox<>();
        durationCombo.getItems().addAll("Full Day", "Half Day");
        if (defaultDuration != null) durationCombo.setValue(defaultDuration);
        else durationCombo.getSelectionModel().selectFirst();
        HBox durBox = new HBox(10, durLbl, durationCombo);
        durBox.setAlignment(Pos.CENTER_LEFT);

        // room ype
        Label roomLbl = new Label("Room Type:");
        ComboBox<String> roomCombo = new ComboBox<>();
        HBox roomBox = new HBox(10, roomLbl, roomCombo);
        roomBox.setAlignment(Pos.CENTER_LEFT);

        // meds checkbox
        CheckBox medsCb = new CheckBox("Give Medication ($5)");

        // date pickers
        DatePicker dropDatePicker = new DatePicker(LocalDate.now());
        dropDatePicker.setDayCellFactory(dp -> new DateCell()
        {
            @Override public void updateItem(LocalDate d, boolean empty)
            {
                super.updateItem(d, empty);
                if (d.isBefore(LocalDate.now())) setDisable(true);
            }
        });

        DatePicker pickDatePicker = new DatePicker(dropDatePicker.getValue().plusDays(1));
        pickDatePicker.setDayCellFactory(dp -> new DateCell()
        {
            @Override public void updateItem(LocalDate d, boolean empty)
            {
                super.updateItem(d, empty);
                if (d.isBefore(dropDatePicker.getValue().plusDays(1))) setDisable(true);
            }
        });
        dropDatePicker.valueProperty().addListener((o,old,newVal) ->
        {
            pickDatePicker.setValue(newVal.plusDays(1));
            pickDatePicker.setDayCellFactory(dp -> new DateCell()

            {
                @Override public void updateItem(LocalDate d, boolean empty)
                {
                    super.updateItem(d, empty);
                    if (d.isBefore(dropDatePicker.getValue().plusDays(1))) setDisable(true);
                }
            });
        });
        HBox dateRow = new HBox(50,
                new HBox(5, new Label("Date:"), dropDatePicker),
                new HBox(5, new Label("Pick‑Up Date:"), pickDatePicker)
        );
        dateRow.setAlignment(Pos.CENTER_LEFT);

        // time dropdowns side by side
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("h:mm a");
        ComboBox<LocalTime> dropCombo = new ComboBox<>();
        ComboBox<LocalTime> pickCombo = new ComboBox<>();
        for (int h = 8; h <= 18; h++) {
            LocalTime t = LocalTime.of(h,0);
            dropCombo.getItems().add(t);
            pickCombo.getItems().add(t);
        }
        StringConverter<LocalTime> timeConv = new StringConverter<>()
        {
            @Override public String toString(LocalTime t)
            {
                return t.format(fmt);
            }
            @Override public LocalTime fromString(String s)
            {
                return LocalTime.parse(s, fmt);
            }
        };
        dropCombo.setConverter(timeConv);
        pickCombo.setConverter(timeConv);
        dropCombo.getSelectionModel().selectFirst();
        pickCombo.getSelectionModel().selectFirst();
        HBox timeRow = new HBox(50,
                new HBox(5, new Label("Drop‑Off Time:"), dropCombo),
                new HBox(5, new Label("Pick‑Up Time:"), pickCombo)
        );
        timeRow.setAlignment(Pos.CENTER_LEFT);

        // total label
        Label totalLabel = new Label("Total Amount: $0.00");
        totalLabel.setStyle("-fx-font-size:16px; -fx-font-weight:bold;");

        // confirm/ cancel buttons
        Button confirm = new Button("Confirm");
        Button cancel  = new Button("Cancel");
        HBox btnBox = new HBox(20, confirm, cancel);
        btnBox.setAlignment(Pos.CENTER);
        cancel.setOnAction(e -> stage.close());

        // disable Confirm
        confirm.disableProperty().bind(
                clientCombo.getSelectionModel().selectedItemProperty().isNull()
        );

        //helpers for rooms total
        Runnable updateRooms = () ->
        {
            roomCombo.getItems().clear();
            if (catRb.isSelected())
            {
                roomCombo.getItems().addAll(
                        "Kitty Condo", "Deluxe Cat Condo (double)", "VIP Kitty Suite (up to 3/suite)"
                );
            }

            else
            {
                roomCombo.getItems().addAll("Deluxe Kennel", "VIP Pup Suite (up to 2/suite)"
                );
            }
            roomCombo.getSelectionModel().selectFirst();
        };
        Runnable computeTotal = () ->

        {
            double total = 0;
            boolean isDC = svcCombo.getValue().equals("Daycare");
            boolean isCat = catRb.isSelected();
            if (isDC) {
                total = durationCombo.getValue().equals("Half Day")
                        ? (isCat ? 20 : 25)
                        : (isCat ? 30 : 35);
            }

            else
            {
                String room = roomCombo.getValue();
                if (isCat)
                {
                    switch (room)
                    {
                        case "Kitty Condo" -> total = 50;
                        case "Deluxe Cat Condo (double)" -> total = 65;
                        case "VIP Kitty Suite (up to 3/suite)" -> total = 100;
                    }
                }

                else
                {
                    switch (room)
                    {
                        case "Deluxe Kennel" -> total = 65;
                        case "VIP Pup Suite (up to 2/suite)" -> total = 110;
                    }
                }
            }
            if (medsCb.isSelected()) total += 5;
            totalLabel.setText(String.format("Total Amount: $%.2f", total));
        };

        boolean initDC = svcCombo.getValue().equals("Daycare");
        durBox.setVisible(initDC);
        roomBox.setVisible(!initDC);

        svcCombo.valueProperty().addListener((o,old,v)->
        {
            boolean dc = v.equals("Daycare");
            durBox.setVisible(dc);
            roomBox.setVisible(!dc);
            if (!dc) updateRooms.run();
            computeTotal.run();
        });

        petToggle.selectedToggleProperty().addListener((o,old,t)->
        {
            updateRooms.run();
            computeTotal.run();
        });
        durationCombo.valueProperty().addListener((o,old,v)-> computeTotal.run());
        roomCombo.valueProperty().addListener((o,old,v)-> computeTotal.run());
        medsCb.selectedProperty().addListener((o,old,v)-> computeTotal.run());

        updateRooms.run();
        computeTotal.run();

        //  pass clientName to Billing
        confirm.setOnAction(e ->
        {
            Pet selectedPet = clientCombo.getValue();
            String clientName = selectedPet.getName();

            Map<String, Double> items = new LinkedHashMap<>();
            boolean isDC = svcCombo.getValue().equals("Daycare");
            boolean isCat = catRb.isSelected();

            if (isDC)
            {
                String d = "Daycare: " + durationCombo.getValue();
                double p = durationCombo.getValue().equals("Half Day")
                        ? (isCat ? 20 : 25)
                        : (isCat ? 30 : 35);
                items.put(d, p);
            }
            else
            {
                String d = "Boarding: " + roomCombo.getValue();
                double p = isCat ? (roomCombo.getValue().equals("VIP Kitty Suite (up to 3/suite)") ? 100 : roomCombo.getValue().equals("Deluxe Cat Condo (double)")   ? 65 : 50)
                        : (roomCombo.getValue().equals("VIP Pup Suite (up to 2/suite)") ? 110 : 65);
                items.put(d, p);
            }
            if (medsCb.isSelected()) items.put("Medication", 5.0);

            stage.close();
            BillingController.showBillingWindow(isCat ? "Cat" : "Dog", clientName, items
            );
        });

        // layout
        VBox content = new VBox(15,
                headerBox,
                svcBox,
                durBox,
                roomBox,
                medsCb,
                dateRow,
                timeRow,
                btnBox
        );
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.TOP_CENTER);

        BorderPane root = new BorderPane(content);
        root.setBottom(new HBox(totalLabel)
        {{
            setAlignment(Pos.CENTER);
            setPadding(new Insets(10));
        }});
        root.setStyle("-fx-background-color:#fcefdb;");

        stage.setScene(new Scene(root, 600, 750));
        stage.show();
    }
}
