package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DaycareController
{
    public static void showDaycareWindow(String petType)
    {
        Stage stage = new Stage();
        stage.setTitle("Daycare Options");

        Label header = new Label("Daycare Options");
        header.setStyle("-fx-font-size:20px; -fx-font-weight:bold;");

        Button fullDay = new Button("Full Day");
        fullDay.setOnAction(e -> {});

        Button halfDay = new Button("Half Day");
        halfDay.setOnAction(e -> {});

        Button back = new Button("Back");
        back.setOnAction(e -> stage.close());

        VBox box = new VBox(10, header, fullDay, halfDay, back);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(20));

        stage.setScene(new Scene(box, 300, 200));
        stage.show();
    }
}
