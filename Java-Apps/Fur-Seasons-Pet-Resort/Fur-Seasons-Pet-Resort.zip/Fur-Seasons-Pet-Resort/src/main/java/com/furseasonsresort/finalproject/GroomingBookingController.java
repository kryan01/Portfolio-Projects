package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class GroomingBookingController
{
    public void showBookingWindow(String serviceType)
    {
        Stage stage = new Stage();
        stage.setTitle(serviceType + " Appointment");

        // header
        Label header = new Label(serviceType + " Appointment");
        header.setStyle("-fx-font-size:20px; -fx-font-weight:bold;");

        // description
        Label desc = new Label("Select a date and time for your " + serviceType.toLowerCase() + " session:");
        desc.setWrapText(true);

        // Client dropdown
        ObservableList<Pet> pets = UserManager.getPets();
        ComboBox<Pet> clientCombo = new ComboBox<>(pets);
        clientCombo.setPromptText("Select Client");
        clientCombo.setConverter(new StringConverter<>()
        {
            @Override public String toString(Pet p)
            {
                return p == null ? "" : p.getName();
            }
            @Override public Pet fromString(String s)
            {
                return null;
            }
        });
        HBox clientBox = new HBox(10, new Label("Client:"), clientCombo);
        clientBox.setAlignment(Pos.CENTER);

        // date picker
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setDayCellFactory(dp -> new DateCell()
        {
            @Override public void updateItem(LocalDate d, boolean empty)
            {
                super.updateItem(d, empty);
                if (d.isBefore(LocalDate.now())) setDisable(true);
            }
        });
        HBox dateBox = new HBox(datePicker);
        dateBox.setAlignment(Pos.CENTER);

        // time dropdown
        Label timeLbl = new Label("Time:");
        ComboBox<LocalTime> timeCombo = new ComboBox<>();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("h:mm a");
        for (int h = 8; h <= 18; h++)
        {
            timeCombo.getItems().add(LocalTime.of(h, 0));
        }
        timeCombo.setConverter(new StringConverter<>()
        {
            @Override public String toString(LocalTime t)
            {
                return t.format(fmt);
            }
            @Override public LocalTime fromString(String s)
            {
                return LocalTime.parse(s, fmt); }

        });
        timeCombo.getSelectionModel().selectFirst();
        HBox timeBox = new HBox(10, timeLbl, timeCombo);
        timeBox.setAlignment(Pos.CENTER);

        // buttons
        Button confirm = new Button("Confirm");
        Button back    = new Button("Back");
        HBox btnBox    = new HBox(10, confirm, back);
        btnBox.setAlignment(Pos.CENTER);

        // disable Confirm till a client is selected
        confirm.disableProperty().bind(clientCombo.getSelectionModel().selectedItemProperty().isNull()
        );

        back.setOnAction(e -> stage.close());

        // build itemized bill and call BillingController
        confirm.setOnAction(e ->
        {
            Pet selected = clientCombo.getValue();
            String clientName = selected.getName();

            Map<String, Double> items = new LinkedHashMap<>();
            double price = serviceType.equals("Full Service") ? 62.0 : 28.0;
            items.put(serviceType, price);

            stage.close();
            BillingController.showBillingWindow(
                    "Grooming",
                    clientName,
                    items
            );
        });

        VBox root = new VBox(15,
                header,
                desc,
                clientBox,
                dateBox,
                timeBox,
                btnBox
        );
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        stage.setScene(new Scene(root, 400, 400));
        stage.show();
    }
}
