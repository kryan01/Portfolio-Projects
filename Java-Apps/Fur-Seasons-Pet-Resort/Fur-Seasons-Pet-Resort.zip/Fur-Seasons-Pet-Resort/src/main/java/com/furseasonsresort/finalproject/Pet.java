package com.furseasonsresort.semesterproject;

import java.io.Serializable;

public class Pet implements Serializable
{
    private String name;
    private final String type;      // species: “Dog” or “Cat”
    private String breed;
    private String age;
    private String sex;
    private String description;

    public Pet(String name, String type)
    {
        this.name = name;
        this.type = type;
        this.breed = "";
        this.age = "";
        this.sex = "";
        this.description = "";
    }

    // name
    public String getName()
    {
        return name;
    }
    public void setName(String name)
    {
        this.name = name;
    }

    // species (type)
    public String getType()
    {
        return type;
    }

    // breed
    public String getBreed()
    {
        return breed;
    }
    public void setBreed(String breed)
    {
        this.breed = breed;
    }

    // age
    public String getAge()
    {
        return age;
    }
    public void setAge(String age)
    {
        this.age = age;
    }

    // Sex
    public String getSex()
    {
        return sex;
    }
    public void setSex(String sex)
    {
        this.sex = sex;
    }

    // Description
    public String getDescription()
    {
        return description;
    }
    public void setDescription(String description)
    {
        this.description = description;
    }

    @Override
    public String toString()
    {
        return name + " (" + type + ")";
    }
}
