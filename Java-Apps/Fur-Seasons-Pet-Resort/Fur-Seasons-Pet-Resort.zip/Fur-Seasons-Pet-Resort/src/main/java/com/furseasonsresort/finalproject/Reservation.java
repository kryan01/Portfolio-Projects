package com.furseasonsresort.semesterproject;

import java.time.LocalDateTime;
import java.util.List;

public class Reservation
{
    private final String ownerUsername;
    private final String serviceName;
    private final String clientName;
    private final LocalDateTime from;
    private final LocalDateTime to;
    private final List<String> details;
    private final double total;
    private final boolean daycare;
    private final String duration; // "Full Day" or "Half Day" for daycare

    public Reservation(String ownerUsername, String serviceName, String clientName, LocalDateTime from, LocalDateTime to, List<String> details, double total,
            boolean daycare, String duration
    )
    {
        this.ownerUsername = ownerUsername;
        this.serviceName   = serviceName;
        this.clientName    = clientName;
        this.from          = from;
        this.to            = to;
        this.details       = details;
        this.total         = total;
        this.daycare       = daycare;
        this.duration      = duration;
    }

    public String getOwnerUsername()
    {
        return ownerUsername;
    }

    public String getServiceName()
    {
        return serviceName;
    }

    public String getClientName()
    {
        return clientName;
    }

    public LocalDateTime getFrom()
    {
        return from;
    }

    public LocalDateTime getTo()
    {
        return to;
    }

    public List<String> getDetails()
    {
        return details;
    }

    public double getTotal()
    {
        return total;
    }

    public boolean isDaycare()
    {
        return daycare;
    }

    public String getDuration()
    {
        return duration;
    }
}
