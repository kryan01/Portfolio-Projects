package com.furseasonsresort.semesterproject;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.ArrayDeque;
import java.util.Deque;

public class Navigation
{
    private static Stage primaryStage;
    private static Deque<Scene> history = new ArrayDeque<>();

    public static void init(Stage stage)
    {
        primaryStage = stage;
    }

    public static void goTo(Scene newScene)
    {
        if (primaryStage.getScene() != null)
        {
            history.push(primaryStage.getScene());
        }
        primaryStage.setScene(newScene);
    }

    public static void goBack()
    {
        if (!history.isEmpty())
        {
            Scene prev = history.pop();
            primaryStage.setScene(prev);
        }
    }
}
