package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.InputStream;

public class PricingController
{
    // display pricing for cats
    static void showCatPricingWindow()
    {
        // title and image
        Stage stage = new Stage();
        stage.setTitle("Cat Pricing");
        ImageView catIcon = new ImageView();
        InputStream catStream = PricingController.class.getResourceAsStream("images/cat.png");
        if (catStream != null)
        {
            Image catImage = new Image(catStream, 100, 0, true, true);
            catIcon.setImage(catImage);
            catIcon.setPreserveRatio(true);
        }
        catIcon.setPreserveRatio(true);

        // labels/ prices
        Label daycare = new Label("- Daycare -");
        Label fullRate = new Label("Full Day (8h): $20");
        Label halfRate = new Label("Half-Day (4h): $30");
        Label boarding = new Label("- Boarding -");
        Label condo = new Label("Kitty Condo: $50 per night");
        Label doubleCondo = new Label("Deluxe Cat Condo (double): $65 per night");
        Label suite = new Label("VIP Kitty Suite (up to 3 /suite): $100 per night");
        Label catio = new Label("Catio Playtime (30m): $18 per day");

        VBox daycareVB = new VBox(10, daycare, halfRate, fullRate);
        VBox boardingVB = new VBox(10, boarding, condo, doubleCondo, suite, catio);
        VBox.setMargin(daycare, new Insets(20,0,0,0));
        VBox.setMargin(boarding, new Insets(20,0,0,0));

        // set alignment and margins:
        daycareVB.setAlignment(Pos.TOP_CENTER);
        boardingVB.setAlignment(Pos.TOP_CENTER);

        // Action buttons: Book and Cancel
        Button bookBtn   = new Button("Book");
        Button cancelBtn = new Button("Cancel");
        bookBtn.setOnAction(e -> new BoardingController().showBoardingWindow("Cat"));
        cancelBtn.setOnAction(e -> stage.close());

        HBox actionBox = new HBox(20, bookBtn, cancelBtn);
        actionBox.setAlignment(Pos.CENTER);
        VBox.setMargin(actionBox, new Insets(20, 0, 0, 0));

        // Vbox
        VBox cat = new VBox(20, catIcon, daycareVB, boardingVB, actionBox);
        cat.setStyle("-fx-text-fill: #748972; " + "-fx-font-size: 18px; " + "-fx-background-color: #fcefdb;"
        );
        cat.setPadding(new Insets(20));
        cat.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(cat, 600, 700);
        stage.setScene(scene);
        stage.show();
    }

    // display pricing for dogs
    static void showDogPricingWindow()
    {
        // title and image
        Stage stage = new Stage();
        stage.setTitle("Dog Pricing");
        ImageView dogIcon = new ImageView();
        InputStream dogStream = PricingController.class.getResourceAsStream("images/dog.png");
        if (dogStream != null)
        {
            Image dogImage = new Image(dogStream, 100, 0, true, true);
            dogIcon.setImage(dogImage);
            dogIcon.setPreserveRatio(true);
        }

        // labels and pricing
        Label daycare = new Label("- Daycare -");
        Label fullDay = new Label("Full Day (8h): $35");
        Label half = new Label("Half-Day (4h): $25");
        Label boarding = new Label("- Boarding -");
        Label deluxe = new Label("Deluxe Kennel: $65 per night");
        Label VIPBoarding = new Label("VIP Pup Suite (up to 2 /suite): $110 per night");
        Label groom = new Label("- Grooming -");
        Label fullService = new Label("Full-Service (wash, cut, nail trim): $62");
        Label bath = new Label("Wash and dry: $28");

        VBox daycareVB = new VBox(10, daycare, fullDay, half);
        VBox boardingVB = new VBox(10, boarding, deluxe, VIPBoarding);
        VBox groomingVB = new VBox(10, groom, fullService, bath);
        daycareVB.setAlignment(Pos.TOP_CENTER);
        boardingVB.setAlignment(Pos.TOP_CENTER);
        groomingVB.setAlignment(Pos.TOP_CENTER);
        VBox.setMargin(daycare, new Insets(20,0,0,0));
        VBox.setMargin(boarding, new Insets(20,0,0,0));
        VBox.setMargin(groom, new Insets(20,0,0,0));

        Button bookBtn   = new Button("Book");
        Button cancelBtn = new Button("Cancel");
        bookBtn.setOnAction(e -> new BoardingController().showBoardingWindow("Dog"));
        cancelBtn.setOnAction(e -> stage.close());

        HBox actionBox = new HBox(30, bookBtn, cancelBtn);
        actionBox.setAlignment(Pos.CENTER);
        VBox.setMargin(actionBox, new Insets(20, 0, 0, 0));

        // Vbox
        VBox dog = new VBox(20, dogIcon, daycareVB, boardingVB, groomingVB, actionBox);
        dog.setStyle("-fx-text-fill: #748972; " + "-fx-font-size:18px; " + "-fx-background-color: #fcefdb;"
        );
        dog.setPadding(new Insets(20));
        dog.setAlignment(Pos.TOP_CENTER);

        Scene scene = new Scene(dog, 600, 700);
        stage.setScene(scene);
        stage.show();
    }
}
