package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class SummaryToLoginController
{
    public static void showLoginWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Login");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        Label lblUser = new Label("Username:");
        TextField tfUser = new TextField();
        Label lblPass = new Label("Password:");
        PasswordField pfPass = new PasswordField();

        Button btnLogin = new Button("Login");
        btnLogin.setOnAction(e ->
        {
            String user = tfUser.getText().trim();
            String pass = pfPass.getText();
            if (user.isEmpty() || pass.isEmpty())
            {
                new Alert(Alert.AlertType.WARNING, "Please enter both username and password.")
                        .showAndWait();
            } else if (UserManager.getOwnerInfo(user) != null)
            {
                UserManager.setCurrentUser(user);
                new Alert(Alert.AlertType.INFORMATION, "Login successful!").showAndWait();
                stage.close();
                UserAccountController.showUserAccountWindow(user);
            }

            else
            {
                new Alert(Alert.AlertType.ERROR, "Invalid credentials.").showAndWait();
            }
        });

        Button btnBack = new Button("Back");
        btnBack.setOnAction(e -> stage.close());

        HBox actions = new HBox(10, btnLogin, btnBack);
        actions.setAlignment(Pos.CENTER_RIGHT);

        grid.add(lblUser,    0, 0);
        grid.add(tfUser,     1, 0);
        grid.add(lblPass,    0, 1);
        grid.add(pfPass,     1, 1);
        grid.add(actions,    1, 2);

        Scene scene = new Scene(grid, 350, 200);
        stage.setScene(scene);
        stage.show();
    }

    public static void showSignUpWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Sign Up");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);

        // Account credentials
        Label lblNewUser    = new Label("Username:");
        TextField tfNewUser = new TextField();
        Label lblNewPass    = new Label("Password:");
        PasswordField pfNewPass = new PasswordField();
        Label lblConfirm    = new Label("Confirm Password:");
        PasswordField pfConfirm = new PasswordField();

        grid.add(lblNewUser,    0, 0);
        grid.add(tfNewUser,     1, 0);
        grid.add(lblNewPass,    0, 1);
        grid.add(pfNewPass,     1, 1);
        grid.add(lblConfirm,    0, 2);
        grid.add(pfConfirm,     1, 2);

        // Owner information fields
        Label lblFirstName      = new Label("First Name:");
        TextField tfFirstName   = new TextField();
        Label lblLastName       = new Label("Last Name:");
        TextField tfLastName    = new TextField();
        Label lblPhone          = new Label("Phone:");
        TextField tfPhone       = new TextField();
        Label lblEmail          = new Label("Email:");
        TextField tfEmail       = new TextField();
        Label lblEmergencyName  = new Label("Emergency Contact Name:");
        TextField tfEmergencyName = new TextField();
        Label lblEmergencyPhone = new Label("Emergency Contact Phone:");
        TextField tfEmergencyPhone = new TextField();

        grid.add(lblFirstName,      0, 3);
        grid.add(tfFirstName,       1, 3);
        grid.add(lblLastName,       0, 4);
        grid.add(tfLastName,        1, 4);
        grid.add(lblPhone,          0, 5);
        grid.add(tfPhone,           1, 5);
        grid.add(lblEmail,          0, 6);
        grid.add(tfEmail,           1, 6);
        grid.add(lblEmergencyName,  0, 7);
        grid.add(tfEmergencyName,   1, 7);
        grid.add(lblEmergencyPhone, 0, 8);
        grid.add(tfEmergencyPhone,  1, 8);

        // Buttons
        Button btnSignUp = new Button("Sign Up");
        btnSignUp.setOnAction(e -> {
            String u = tfNewUser.getText().trim();
            String p = pfNewPass.getText().trim();
            String c = pfConfirm.getText().trim();

            // basic validations
            if (u.isEmpty() || p.isEmpty()
                    || tfFirstName.getText().trim().isEmpty()
                    || tfLastName.getText().trim().isEmpty()
                    || tfPhone.getText().trim().isEmpty()
                    || tfEmail.getText().trim().isEmpty()
                    || tfEmergencyName.getText().trim().isEmpty()
                    || tfEmergencyPhone.getText().trim().isEmpty())
            {
                new Alert(Alert.AlertType.WARNING, "All fields are required.").showAndWait();
                return;
            }

            if (!p.equals(c))
            {
                new Alert(Alert.AlertType.WARNING, "Passwords do not match.").showAndWait();
                return;
            }

            if (UserManager.register(u, p))
            {
                new Alert(Alert.AlertType.INFORMATION, "Registration successful!").showAndWait();
                stage.close();

                // Save owner info
                OwnerInfo oi = new OwnerInfo(
                        tfFirstName.getText().trim(),
                        tfLastName.getText().trim(),
                        tfPhone.getText().trim(),
                        tfEmail.getText().trim(),
                        tfEmergencyName.getText().trim(),
                        tfEmergencyPhone.getText().trim()
                );
                UserManager.setOwnerInfo(u, oi);

                // go to pet registration
                PetRegistrationController.showRegistrationWindow();
            }

            else
            {
                new Alert(Alert.AlertType.ERROR, "Username already exists.").showAndWait();
            }
        });

        Button btnBack = new Button("Back");
        btnBack.setOnAction(e -> stage.close());

        HBox signButtons = new HBox(10, btnSignUp, btnBack);
        signButtons.setAlignment(Pos.CENTER_RIGHT);
        grid.add(signButtons, 1, 9);

        Scene scene = new Scene(grid, 450, 500);
        stage.setScene(scene);
        stage.show();
    }
}
