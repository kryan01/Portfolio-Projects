package com.furseasonsresort.semesterproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class PetProfileController
{

    public static void showAddPetWindow(ObservableList<Pet> pets)
    {
        Stage stage = new Stage();
        stage.setTitle("Add New Pet");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label lblName = new Label("Pet Name:");
        TextField tfName = new TextField();
        Label lblType = new Label("Type:");
        ComboBox<String> cbType = new ComboBox<>(FXCollections.observableArrayList("Dog", "Cat", "Other"));
        cbType.getSelectionModel().selectFirst();

        Button btnAdd = new Button("Add");
        btnAdd.setOnAction(e ->
        {
            String name = tfName.getText().trim();
            String type = cbType.getValue();
            if (name.isEmpty())
            {
                new Alert(Alert.AlertType.WARNING, "Please enter a pet name.").showAndWait();
            }
            else
            {
                pets.add(new Pet(name, type));
                stage.close();
            }
        });
        Button btnCancel = new Button("Cancel");
        btnCancel.setOnAction(e -> stage.close());

        HBox buttons = new HBox(10, btnAdd, btnCancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        grid.add(lblName, 0, 0);
        grid.add(tfName, 1, 0);
        grid.add(lblType, 0, 1);
        grid.add(cbType, 1, 1);
        grid.add(buttons, 1, 2);

        Scene scene = new Scene(grid, 350, 200);
        stage.setScene(scene);
        stage.show();
    }

    public static void showEditPetWindow(Pet pet) {
        Stage stage = new Stage();
        stage.setTitle("Edit Pet");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label lblName = new Label("Pet Name:");
        TextField tfName = new TextField(pet.getName());

        Button btnSave = new Button("Save");
        btnSave.setOnAction(e ->
        {
            String newName = tfName.getText().trim();
            if (newName.isEmpty())
            {
                new Alert(Alert.AlertType.WARNING, "Name cannot be empty.").showAndWait();
            }

            else
            {
                pet.setName(newName);
                stage.close();
            }
        });
        Button btnCancel = new Button("Cancel");
        btnCancel.setOnAction(e -> stage.close());

        HBox buttons = new HBox(10, btnSave, btnCancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        grid.add(lblName, 0, 0);
        grid.add(tfName, 1, 0);
        grid.add(buttons, 1, 1);

        Scene scene = new Scene(grid, 350, 150);
        stage.setScene(scene);
        stage.show();
    }
}
