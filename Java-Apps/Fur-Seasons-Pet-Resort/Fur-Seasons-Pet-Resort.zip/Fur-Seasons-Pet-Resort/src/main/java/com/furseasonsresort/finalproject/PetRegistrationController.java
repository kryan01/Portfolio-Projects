package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PetRegistrationController
{

    public static void showRegistrationWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Register Your Pet(s)");

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label header = new Label("Pet Profile Registration");
        header.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");

        // pet forms
        VBox petsContainer = new VBox(10);
        petsContainer.setAlignment(Pos.TOP_CENTER);

        addPetForm(petsContainer);

        // Add Pet button
        Button addPetBtn = new Button("Add Another Pet");
        addPetBtn.setOnAction(e -> addPetForm(petsContainer));

        // save profiles button
        Button saveBtn = new Button("Save Profiles");
        saveBtn.setOnAction(e -> {
            ObservableList<Pet> userPets = UserManager.getPets();
            userPets.clear();

            for (javafx.scene.Node node : petsContainer.getChildren())
            {
                if (node instanceof GridPane)
                {
                    GridPane form = (GridPane) node;

                    String name    = ((TextField)getNode(form, 1, 0)).getText().trim();
                    String breed   = ((TextField)getNode(form, 1, 1)).getText().trim();
                    String ageStr  = ((TextField)getNode(form, 1, 2)).getText().trim();
                    String sex     = ((ComboBox<String>)getNode(form, 1, 3)).getValue();
                    String species = ((ComboBox<String>)getNode(form, 1, 4)).getValue();

                    if (!name.isEmpty())
                    {
                        Pet pet = new Pet(name, species);
                        userPets.add(pet);
                    }
                }
            }

            new Alert(Alert.AlertType.INFORMATION, "Pet profiles saved!").showAndWait();
            stage.close();
        });

        HBox buttonsBox = new HBox(10, addPetBtn, saveBtn);
        buttonsBox.setAlignment(Pos.CENTER);

        root.getChildren().addAll(header, petsContainer, buttonsBox);

        stage.setScene(new Scene(root, 450, 500));
        stage.show();
    }

    private static void addPetForm(VBox container) {
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.setPadding(new Insets(10));
        form.setStyle("-fx-border-color:#cccccc; -fx-border-radius:5; -fx-padding:10;");

        form.add(new Label("Name:"),      0, 0);
        form.add(new TextField(),         1, 0);

        form.add(new Label("Breed:"),     0, 1);
        form.add(new TextField(),         1, 1);

        form.add(new Label("Age:"),       0, 2);
        form.add(new TextField(),         1, 2);

        form.add(new Label("Sex:"),       0, 3);
        ComboBox<String> cbSex = new ComboBox<>();
        cbSex.getItems().addAll("Male", "Female");
        cbSex.getSelectionModel().selectFirst();
        form.add(cbSex,                   1, 3);

        form.add(new Label("Species:"),   0, 4);
        ComboBox<String> cbSpecies = new ComboBox<>();
        cbSpecies.getItems().addAll("Cat", "Dog");
        cbSpecies.getSelectionModel().selectFirst();
        form.add(cbSpecies,               1, 4);

        container.getChildren().add(form);
    }

    private static javafx.scene.Node getNode(GridPane grid, int col, int row)
    {
        for (javafx.scene.Node node : grid.getChildren())
        {
            Integer c = GridPane.getColumnIndex(node), r = GridPane.getRowIndex(node);
            if (c != null && r != null && c == col && r == row)
            {
                return node;
            }
        }
        return null;
    }
}
