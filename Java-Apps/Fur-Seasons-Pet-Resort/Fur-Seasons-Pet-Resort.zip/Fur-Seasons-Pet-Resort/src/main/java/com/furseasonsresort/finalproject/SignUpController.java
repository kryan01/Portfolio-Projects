package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SignUpController
{

    public static void showSignUpWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Sign Up");

        VBox formBox = new VBox(15);
        formBox.setPadding(new Insets(20));
        formBox.setAlignment(Pos.TOP_CENTER);
        formBox.setStyle("-fx-background-color:#fcefdb;");

        // owner section header
        Label ownerHdr = new Label("Owner Information");
        ownerHdr.setStyle("-fx-font-size:16px; -fx-font-weight:bold;");
        formBox.getChildren().add(ownerHdr);

        GridPane ownerGrid = new GridPane();
        ownerGrid.setHgap(10);
        ownerGrid.setVgap(10);
        ownerGrid.setAlignment(Pos.CENTER_LEFT);

        TextField usernameField     = new TextField();
        PasswordField passwordField = new PasswordField();
        PasswordField confirmField  = new PasswordField();
        TextField firstNameField    = new TextField();
        TextField lastNameField     = new TextField();
        TextField phoneField        = new TextField();
        TextField emailField        = new TextField();
        TextField emNameField       = new TextField();
        TextField emPhoneField      = new TextField();

        ownerGrid.add(new Label("Username:"),                0, 0);
        ownerGrid.add(usernameField,                         1, 0);
        ownerGrid.add(new Label("Password:"),                0, 1);
        ownerGrid.add(passwordField,                         1, 1);
        ownerGrid.add(new Label("Confirm Password:"),        0, 2);
        ownerGrid.add(confirmField,                          1, 2);
        ownerGrid.add(new Label("First Name:"),              0, 3);
        ownerGrid.add(firstNameField,                        1, 3);
        ownerGrid.add(new Label("Last Name:"),               0, 4);
        ownerGrid.add(lastNameField,                         1, 4);
        ownerGrid.add(new Label("Phone:"),                   0, 5);
        ownerGrid.add(phoneField,                            1, 5);
        ownerGrid.add(new Label("Email:"),                   0, 6);
        ownerGrid.add(emailField,                            1, 6);
        ownerGrid.add(new Label("Emergency Contact Name:"),  0, 7);
        ownerGrid.add(emNameField,                           1, 7);
        ownerGrid.add(new Label("Emergency Contact Phone:"), 0, 8);
        ownerGrid.add(emPhoneField,                          1, 8);

        formBox.getChildren().add(ownerGrid);

        // pet section
        Label petsHdr = new Label("Pet Profiles");
        petsHdr.setStyle("-fx-font-size:16px; -fx-font-weight:bold;");
        formBox.getChildren().add(petsHdr);

        VBox formsContainer = new VBox(10);
        formsContainer.setAlignment(Pos.TOP_CENTER);
        addPetForm(formsContainer);  // initial pet form
        formBox.getChildren().add(formsContainer);

        // add pet button
        Button addPetBtn = new Button("Add Another Pet");
        addPetBtn.setOnAction(e -> addPetForm(formsContainer));
        formBox.getChildren().add(addPetBtn);

        Button signUpBtn = new Button("Sign Up");
        Button backBtn   = new Button("Back");
        HBox actionRow = new HBox(10, signUpBtn, backBtn);
        actionRow.setAlignment(Pos.CENTER);
        formBox.getChildren().add(actionRow);

        ScrollPane rootScroll = new ScrollPane(formBox);
        rootScroll.setFitToWidth(true);
        rootScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        rootScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        rootScroll.setStyle("-fx-background:#fcefdb; -fx-background-color:#fcefdb;");

        // Sign‑up logic
        signUpBtn.setOnAction(e ->
        {
            String user = usernameField.getText().trim();
            String pw   = passwordField.getText();
            String cpw  = confirmField.getText();
            if (user.isEmpty() || pw.isEmpty() || cpw.isEmpty())
            {
                new Alert(Alert.AlertType.ERROR, "Username & passwords required.").showAndWait();
                return;
            }

            if (!pw.equals(cpw))
            {
                new Alert(Alert.AlertType.ERROR, "Passwords do not match.").showAndWait();
                return;
            }

            if (!UserManager.register(user, pw))
            {
                new Alert(Alert.AlertType.ERROR, "Username already taken.").showAndWait();
                return;
            }

            UserManager.setCurrentUser(user);

            // Save owner info
            OwnerInfo oi = new OwnerInfo(firstNameField.getText().trim(), lastNameField.getText().trim(), phoneField.getText().trim(),
                    emailField.getText().trim(), emNameField.getText().trim(), emPhoneField.getText().trim());
            UserManager.setOwnerInfo(user, oi);

            ObservableList<Pet> pets = UserManager.getPets();
            pets.clear();
            for (Node n : formsContainer.getChildren())
            {
                if (n instanceof GridPane)
                {
                    GridPane pg = (GridPane) n;
                    String nm = ((TextField)getNode(pg,1,0)).getText().trim();
                    String br = ((TextField)getNode(pg,1,1)).getText().trim();
                    String ag = ((TextField)getNode(pg,1,2)).getText().trim();
                    String sx = ((ComboBox<String>)getNode(pg,1,3)).getValue();
                    String sp = ((ComboBox<String>)getNode(pg,1,4)).getValue();
                    String ds = ((TextArea)getNode(pg,1,5)).getText().trim();
                    if (!nm.isEmpty())
                    {
                        Pet p = new Pet(nm, sp);
                        p.setBreed(br);
                        p.setAge(ag);
                        p.setSex(sx);
                        p.setDescription(ds);
                        pets.add(p);
                    }
                }
            }

            stage.close();
            UserAccountController.showUserAccountWindow(user);
        });

        backBtn.setOnAction(e -> stage.close());

        // Show scene
        Scene scene = new Scene(rootScroll, 550, 700);
        stage.setScene(scene);
        stage.show();
    }

    private static void addPetForm(VBox container)
    {
        GridPane form = new GridPane();
        form.setHgap(8);
        form.setVgap(8);
        form.setPadding(new Insets(10));
        form.setStyle("-fx-border-color:#cccccc; -fx-border-radius:4;");

        form.add(new Label("Name:"),       0, 0);
        form.add(new TextField(),          1, 0);

        form.add(new Label("Breed:"),      0, 1);
        form.add(new TextField(),          1, 1);

        form.add(new Label("Age:"),        0, 2);
        form.add(new TextField(),          1, 2);

        form.add(new Label("Sex:"),        0, 3);
        ComboBox<String> sexCb = new ComboBox<>();
        sexCb.getItems().addAll("Male","Female");
        sexCb.getSelectionModel().selectFirst();
        form.add(sexCb,                    1, 3);

        form.add(new Label("Species:"),    0, 4);
        ComboBox<String> spCb = new ComboBox<>();
        spCb.getItems().addAll("Cat","Dog");
        spCb.getSelectionModel().selectFirst();
        form.add(spCb,                     1, 4);

        form.add(new Label("Description:"),0, 5);
        TextArea descArea = new TextArea();
        descArea.setPrefRowCount(2);
        form.add(descArea,                 1, 5);

        container.getChildren().add(form);
    }

    private static Node getNode(GridPane grid, int col, int row)
    {
        for (Node n : grid.getChildren())
        {
            Integer c = GridPane.getColumnIndex(n), r = GridPane.getRowIndex(n);
            if (c != null && r != null && c == col && r == row)
            {
                return n;
            }
        }
        return null;
    }
}
