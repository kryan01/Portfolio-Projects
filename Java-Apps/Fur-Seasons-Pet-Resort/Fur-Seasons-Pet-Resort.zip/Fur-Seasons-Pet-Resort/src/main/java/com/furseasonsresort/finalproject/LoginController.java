package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController
{

    public static void showLoginWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Login");

        Label header = new Label("Login");
        header.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");

        // username/email fail
        Label userLbl = new Label("Username:");
        TextField userField = new TextField();
        userField.setPromptText("Enter username");

        // password field
        Label passLbl = new Label("Password:");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Enter password");

        Button loginBtn = new Button("Login");
        loginBtn.setDefaultButton(true);
        loginBtn.setOnAction(e -> { String username = userField.getText().trim();String password = passField.getText();
            if (username.isEmpty())
            {
                return;
            }
            boolean success = UserManager.login(username, password);
            if (success)
            {
                stage.close();
                // to user account page
                UserAccountController.showUserAccountWindow(username);
            }

            else
            {
                new Alert(Alert.AlertType.ERROR, "Invalid username or password.").showAndWait();
            }
        });

        Button signUpBtn = new Button("Sign Up");
        signUpBtn.setOnAction(e -> {
            stage.close();
            SignUpController.showSignUpWindow();
        });

        HBox buttonsRow = new HBox(10, loginBtn, signUpBtn);
        buttonsRow.setAlignment(Pos.CENTER);

        // back button
        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> stage.close());

        VBox root = new VBox(10, header, userLbl, userField, passLbl, passField, buttonsRow, backBtn
        );
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color:#fcefdb;");

        stage.setScene(new Scene(root, 360, 320));
        stage.show();
    }
}
