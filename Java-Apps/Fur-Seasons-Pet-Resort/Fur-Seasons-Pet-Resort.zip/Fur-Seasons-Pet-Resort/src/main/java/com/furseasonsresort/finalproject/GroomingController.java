

package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class GroomingController
{

    public void showBookingWindow(String serviceType)
    {
        Stage stage = new Stage();
        stage.setTitle(serviceType + " Appointment");

        Label header = new Label(serviceType + " Appointment");
        header.setStyle("-fx-font-size:20px; -fx-font-weight:bold;");

        Label desc = new Label("Select a date and time for your " + serviceType.toLowerCase() + " session:");
        desc.setWrapText(true);

        // date picker
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setDayCellFactory(dp -> new DateCell()
        {
            @Override public void updateItem(LocalDate date, boolean empty)
            {
                super.updateItem(date, empty);
                if (date.isBefore(LocalDate.now())) setDisable(true);
            }
        });

        // time dropdown
        Label timeLbl = new Label("Time:");
        ComboBox<LocalTime> timeCombo = new ComboBox<>();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("h:mm a");
        for (int h = 8; h <= 18; h++)
        {
            timeCombo.getItems().add(LocalTime.of(h, 0));
        }
        timeCombo.setConverter(new StringConverter<LocalTime>()
        {
            @Override public String toString(LocalTime t)
            {
                return t.format(fmt);
            }
            @Override public LocalTime fromString(String s)
            {
                return LocalTime.parse(s, fmt);
            }
        });
        timeCombo.getSelectionModel().selectFirst();
        HBox timeBox = new HBox(10, timeLbl, timeCombo);
        timeBox.setAlignment(Pos.CENTER);

        Button confirm = new Button("Confirm");
        confirm.setOnAction(e -> stage.close());

        Button back = new Button("Back");
        back.setOnAction(e -> stage.close());

        VBox root = new VBox(15, header, desc, datePicker, timeBox, confirm, back);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        stage.setScene(new Scene(root, 400, 400));
        stage.show();
    }
}
