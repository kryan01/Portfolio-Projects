package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Button;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UserAccountController
{
    public static void showUserAccountWindow(String username)
    {
        Stage stage = new Stage();
        stage.setTitle(username + " Account");

        // TabPane setup
        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // owner profile tab
        OwnerInfo info = UserManager.getOwnerInfo(username);
        VBox ownerBox = new VBox(8);
        ownerBox.setPadding(new Insets(20));
        ownerBox.setAlignment(Pos.TOP_LEFT);
        ownerBox.setStyle("-fx-background-color:#fcefdb;");

        if (info != null)
        {
            ownerBox.getChildren().addAll(
                    new Label("Name:  " + info.getFirstName() + " " + info.getLastName()),
                    new Label("Phone: " + info.getPhone()),
                    new Label("Email: " + info.getEmail()),
                    new Separator(),
                    new Label("Emergency Contact:"),
                    new Label("  " + info.getEmergencyName()),
                    new Label("  " + info.getEmergencyPhone())
            );
        }

        else
        {
            ownerBox.getChildren().add(new Label("No owner information available."));
        }
        tabs.getTabs().add(new Tab("Owner Profile", ownerBox));

        //profile tab

        VBox petBox = new VBox(8);
        petBox.setPadding(new Insets(20));
        petBox.setAlignment(Pos.TOP_LEFT);
        petBox.setStyle("-fx-background-color:#fcefdb;");

        petBox.getChildren().add(new Label("Pet Profile"));

        if (UserManager.getPets().isEmpty())
        {
            petBox.getChildren().add(new Label("No pet profile available."));
        }

        else
        {
            for (Pet pet : UserManager.getPets())
            {
                petBox.getChildren().addAll(
                        new Label("Name:        " + pet.getName()),
                        new Label("Breed:       " + pet.getBreed()),
                        new Label("Age:         " + pet.getAge()),
                        new Label("Sex:         " + pet.getSex()),
                        new Label("Species:     " + pet.getType()),
                        new Label("Description: " + pet.getDescription()),
                        new Separator()
                );
            }
        }
        tabs.getTabs().add(new Tab("Pet Profile", petBox));


        // payment method tab
        VBox payBox = new VBox(12);
        payBox.setPadding(new Insets(20));
        payBox.setAlignment(Pos.TOP_LEFT);
        payBox.setStyle("-fx-background-color:#fcefdb;");

        payBox.getChildren().add(new Label("Payment Methods"));

        if (UserManager.getPaymentMethods().isEmpty())
        {
            payBox.getChildren().add(new Label("No payment methods saved."));
        } else {
            for (PaymentMethod pm : UserManager.getPaymentMethods())
            {
                Label nameLbl = new Label(pm.getCardholderName());
                nameLbl.setStyle("-fx-font-weight:bold;");
                Label numLbl  = new Label(pm.getMaskedNumber());

                VBox cardBox = new VBox(2, nameLbl, numLbl);
                cardBox.setPadding(new Insets(8));
                cardBox.setStyle(
                        "-fx-border-color:#cccccc; " +
                                "-fx-border-radius:4; " +
                                "-fx-background-color:white;"
                );
                payBox.getChildren().add(cardBox);
            }
        }

        Button addPm = new Button("Add Payment Method");
        addPm.setOnAction(e -> PaymentMethodController.showPaymentMethodWindow());
        payBox.getChildren().add(addPm);

        tabs.getTabs().add(new Tab("Payment Method", payBox));


        VBox root = new VBox(tabs);
        root.setPadding(new Insets(10));
        VBox.setVgrow(tabs, Priority.ALWAYS);
        root.setStyle("-fx-background-color:#fcefdb;");

        stage.setScene(new Scene(root, 600, 600));
        stage.show();
    }
}
