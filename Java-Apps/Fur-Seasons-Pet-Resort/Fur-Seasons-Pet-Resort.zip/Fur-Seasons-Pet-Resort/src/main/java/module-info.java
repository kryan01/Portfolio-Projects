module com.furseasonsresort.semesterproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.furseasonsresort.semesterproject to javafx.fxml;
    exports com.furseasonsresort.semesterproject;
}