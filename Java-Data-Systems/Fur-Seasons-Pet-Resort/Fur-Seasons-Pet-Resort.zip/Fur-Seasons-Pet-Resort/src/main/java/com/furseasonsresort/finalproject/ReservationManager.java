package com.furseasonsresort.semesterproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ReservationManager
{
    private static final ObservableList<Reservation> upcoming =
            FXCollections.observableArrayList();


    public static ObservableList<Reservation> getUpcoming()
    {
        return upcoming;
    }


    public static void addReservation(Reservation r)
    {
        upcoming.add(r);
    }
}
