package com.furseasonsresort.semesterproject;

import java.io.Serializable;

public class PaymentMethod implements Serializable
{
    private final String cardholderName;
    private final String cardNumber; // store digits

    public PaymentMethod(String cardholderName, String cardNumber)
    {
        this.cardholderName = cardholderName;
        this.cardNumber     = cardNumber.replaceAll("\\D", ""); // keep digits
    }

    public String getCardholderName()
    {
        return cardholderName;
    }

    public String getCardNumber()
    {
        return cardNumber;
    }

    public String getMaskedNumber()
    {
        if (cardNumber.length() <= 4)
        {
            return cardNumber;
        }
        String last4 = cardNumber.substring(cardNumber.length() - 4);
        return "********" + last4;
    }
}
