package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ReservationController
{
    public static void showReservationWindow()
    {
        //  be logged in
        if (!UserManager.isLoggedIn())
        {
            Alert a = new Alert(Alert.AlertType.INFORMATION,
                    "Please log in to view your reservations.", ButtonType.OK);
            a.showAndWait();
            SummaryToLoginController.showLoginWindow();
            return;
        }

        String currentUser = UserManager.getCurrentUser();

        Stage stage = new Stage();
        stage.setTitle("Reservation Summary");

        try
        {
            TabPane tabPane = new TabPane();
            tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

            // reservation tab
            VBox listContainer = new VBox(10);
            listContainer.setPadding(new Insets(20));
            listContainer.setStyle("-fx-background-color:#fcefdb;");

            // only current user
            ObservableList<Reservation> upcomingAll = ReservationManager.getUpcoming();
            ObservableList<Reservation> upcoming = upcomingAll.filtered(
                    res -> currentUser.equals(res.getOwnerUsername())
            );

            if (upcoming.isEmpty())
            {
                listContainer.getChildren().add(new Label("No upcoming reservations."));
            }

            else
            {
                for (Reservation res : upcoming)
                {
                    VBox box = new VBox(5);
                    box.setPadding(new Insets(10));
                    box.setStyle("-fx-background-color: #f3e6f5; " + "-fx-border-color: #d1b3d4; " + "-fx-border-radius: 5; " + "-fx-background-radius: 5;"
                    );

                    HBox header = new HBox();
                    header.setAlignment(Pos.CENTER_LEFT);
                    Label serviceLbl = new Label(res.getServiceName());
                    serviceLbl.setStyle("-fx-font-weight:bold; -fx-text-fill:white;");
                    Region spacer = new Region();
                    HBox.setHgrow(spacer, Priority.ALWAYS);
                    Label clientLbl = new Label("Client: " + res.getClientName());
                    clientLbl.setStyle("-fx-text-fill:white;");
                    header.getChildren().addAll(serviceLbl, spacer, clientLbl);

                    // when label
                    Label whenLbl;
                    if ("Grooming".equals(res.getServiceName()))
                    {
                        whenLbl = new Label("Time: " + res.getFrom().toLocalTime() + "   Date: " + res.getFrom().toLocalDate()
                        );
                    } else if (res.isDaycare())
                    {
                        whenLbl = new Label("Daycare: " + res.getDuration() + "\n" + "Time: " + res.getFrom().toLocalTime() + "   Date: " + res.getFrom().toLocalDate()
                        );
                    }

                    else
                    {
                        whenLbl = new Label("From: " + res.getFrom().toLocalTime() + "   " + res.getFrom().toLocalDate() + "\n" + "To:     " + res.getTo().toLocalTime() + "   " + res.getTo().toLocalDate()
                        );
                    }
                    whenLbl.setStyle("-fx-text-fill:white;");

                    // details
                    VBox detailsBox = new VBox(2);
                    detailsBox.setPadding(new Insets(5, 0, 0, 0));
                    for (String d : res.getDetails())
                    {
                        Label lbl = new Label(d);
                        lbl.setStyle("-fx-text-fill:white;");
                        detailsBox.getChildren().add(lbl);
                    }

                    //total
                    Label totalLbl = new Label("Total: $" + String.format("%.2f", res.getTotal()));
                    totalLbl.setStyle("-fx-text-fill:white; -fx-font-weight:bold;");
                    HBox totalRow = new HBox(totalLbl);
                    totalRow.setAlignment(Pos.CENTER_RIGHT);

                    box.getChildren().addAll(header, whenLbl, detailsBox, totalRow);
                    listContainer.getChildren().add(box);
                }
            }

            ScrollPane scroll = new ScrollPane(listContainer);
            scroll.setFitToWidth(true);
            scroll.setStyle("-fx-background:transparent;");

            Button back = new Button("Back");
            back.setOnAction(e -> stage.close());
            HBox backBox = new HBox(back);
            backBox.setAlignment(Pos.CENTER);
            backBox.setPadding(new Insets(10));

            VBox reservationsContent = new VBox(scroll, backBox);
            reservationsContent.setSpacing(10);

            Tab reservationsTab = new Tab("Reservations", reservationsContent);

            // waiver Tab
            Label waiverHeader = new Label("Fur Seasons Resort Waiver");
            waiverHeader.setStyle("-fx-font-size:20px; -fx-font-weight:bold;");
            Label waiverText = new Label("This waiver covers all services provided by Fur Seasons Resort. " +
                    "By acknowledging below, you agree:\n\n" +
                    "• Your pet is in good health and vaccinated.\n" +
                    "• Fur Seasons Resort and its staff are not liable for unforeseen injuries.\n" +
                    "• You authorize emergency veterinary treatment at your expense.\n" +
                    "• You agree to all terms and conditions as set forth above."
            );
            waiverText.setWrapText(true);
            waiverText.setMaxWidth(450);

            CheckBox ackCb = new CheckBox("I acknowledge that I have read and understand this waiver");
            ackCb.setWrapText(true);
            ackCb.setMaxWidth(450);

            Button signBtn = new Button("Sign Waiver");
            signBtn.setDisable(true);
            ackCb.selectedProperty().addListener((o, old, sel) -> signBtn.setDisable(!sel));
            signBtn.setOnAction(e ->
            {
                signBtn.setText("Waiver Signed");
                signBtn.setDisable(true);
                ackCb.setDisable(true);
            });

            Button backW = new Button("Back");
            backW.setOnAction(e -> stage.close());

            VBox waiverBox = new VBox(15, waiverHeader, waiverText, ackCb, signBtn, backW);
            waiverBox.setAlignment(Pos.TOP_CENTER);
            waiverBox.setPadding(new Insets(20));
            waiverBox.setStyle("-fx-background-color:#fcefdb;");
            Tab waiverTab = new Tab("Waiver", waiverBox);

            tabPane.getTabs().addAll(reservationsTab, waiverTab);

            stage.setScene(new Scene(tabPane, 550, 450));
            stage.show();

        }

        catch (Exception ex)
        {
            ex.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Failed to open Reservation window:\n" + ex.getMessage(), ButtonType.OK).showAndWait();
        }
    }
}
