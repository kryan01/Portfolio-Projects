package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.text.DecimalFormat;
import java.util.Map;

public class BillingController
{

    private static final DecimalFormat DF = new DecimalFormat("#,##0.00");

    public static void showBillingWindow(String petType, String clientName, Map<String, Double> items)
    {
        Stage stage = new Stage();
        stage.setTitle("Billing");

        VBox root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color:#fcefdb;");

        // Pet type on left, Client on right
        HBox headerRow = new HBox();
        headerRow.setAlignment(Pos.CENTER_LEFT);
        Label petLabel = new Label(petType);
        petLabel.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label clientLabel = new Label("Client: " + clientName);
        clientLabel.setStyle("-fx-font-size:14px; -fx-font-weight:normal;");
        headerRow.getChildren().addAll(petLabel, spacer, clientLabel);
        root.getChildren().add(headerRow);

        // line items
        double total = 0;
        for (Map.Entry<String, Double> e : items.entrySet())
        {
            String desc = e.getKey();
            double price = e.getValue();
            total += price;

            Label descLbl = new Label(desc);
            Label priceLbl = new Label("$" + DF.format(price));
            HBox line = new HBox();
            line.setAlignment(Pos.CENTER_LEFT);
            HBox.setHgrow(descLbl, Priority.ALWAYS);
            descLbl.setMaxWidth(Double.MAX_VALUE);
            line.getChildren().addAll(descLbl, priceLbl);
            root.getChildren().add(line);
        }

        // total label
        root.getChildren().add(new Separator());
        Label totalLbl = new Label("Total Amount: $" + DF.format(total));
        totalLbl.setStyle("-fx-font-size:16px; -fx-font-weight:bold;");

        // checkout button
        Button checkoutBtn = new Button("Checkout");
        checkoutBtn.setOnAction(e ->
        {
            stage.close();
            CheckoutController.showCheckoutWindow();
        });

        HBox bottomBox = new HBox(10, totalLbl, checkoutBtn);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10, 0, 0, 0));
        root.getChildren().add(bottomBox);

        stage.setScene(new Scene(root, 500, 350));
        stage.show();
    }
}
