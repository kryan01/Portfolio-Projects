package com.furseasonsresort.semesterproject;

public enum RoomType
{
    SINGLE(50), DOUBLE(80), SUITE(120);
    private final double rate;
    RoomType(double r)
    {
        rate = r;
    }
    public double getRate()
    {
        return rate;
    }
}