package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.InputStream;

public class ServicesController
{
    public static void showServicesWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Services");

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setStyle("-fx-background-color:#fcefdb;");

        // grooming tab
        Label groomingHeader = new Label("Grooming");
        groomingHeader.setStyle("-fx-font-size:20px; -fx-font-weight:bold; -fx-text-fill: #748972;");
        Label groomingDesc = new Label("Choose a grooming package:");
        groomingDesc.setWrapText(true);
        groomingDesc.setMaxWidth(300);
        groomingDesc.setStyle("-fx-font-size:14px;");

        Button fullServiceBtn = new Button("Full Service ($62)");
        fullServiceBtn.setOnAction(e -> new GroomingBookingController().showBookingWindow("Full Service"));

        Button washOnlyBtn = new Button("Wash Only ($28)");
        washOnlyBtn.setOnAction(e -> new GroomingBookingController().showBookingWindow("Wash Only"));

        Button backG = new Button("Back");
        backG.setOnAction(e -> stage.close());

        VBox groomBox = new VBox(10, groomingHeader, groomingDesc, fullServiceBtn, washOnlyBtn, backG);
        groomBox.setAlignment(Pos.CENTER);
        groomBox.setPadding(new Insets(20));
        groomBox.setStyle("-fx-background-color:#fcefdb;");

        Tab groomingTab = new Tab("Grooming", groomBox);

        // daycare Tab ---
        Label daycareHeader = new Label("Daycare");
        daycareHeader.setStyle("-fx-font-size:20px; -fx-font-weight:bold; -fx-text-fill: #748972;");

        ImageView catPlay = new ImageView();
        InputStream catStr = ServicesController.class.getResourceAsStream("images/cat-playing.png");
        if (catStr != null)
        {
            Image i = new Image(catStr, 0, 200, true, true);
            catPlay.setImage(i);
            catPlay.setPreserveRatio(true);
        }
        Button catFull = new Button("Full Day ($30)");
        catFull.setOnAction(e -> new BoardingController().showBoardingWindow("Cat", "Full Day"));
        Button catHalf = new Button("Half Day ($20)");
        catHalf.setOnAction(e -> new BoardingController().showBoardingWindow("Cat", "Half Day"));
        VBox catBox = new VBox(8, new Label("Cats"), catPlay, catFull, catHalf);
        catBox.setAlignment(Pos.CENTER);

        ImageView dogPlay = new ImageView();
        InputStream dogStr = ServicesController.class.getResourceAsStream("images/dog-playing.png");
        if (dogStr != null)
        {
            Image i = new Image(dogStr, 0, 200, true, true);
            dogPlay.setImage(i);
            dogPlay.setPreserveRatio(true);
        }
        Button dogFull = new Button("Full Day ($35)");
        dogFull.setOnAction(e -> new BoardingController().showBoardingWindow("Dog", "Full Day"));
        Button dogHalf = new Button("Half Day ($25)");
        dogHalf.setOnAction(e -> new BoardingController().showBoardingWindow("Dog", "Half Day"));
        VBox dogBox = new VBox(8, new Label("Dogs"), dogPlay, dogFull, dogHalf);
        dogBox.setAlignment(Pos.CENTER);

        Button backD = new Button("Back");
        backD.setOnAction(e -> stage.close());

        HBox dayContent = new HBox(40, catBox, dogBox);
        dayContent.setAlignment(Pos.CENTER);
        VBox daycareBox = new VBox(10, daycareHeader, dayContent, backD);
        daycareBox.setAlignment(Pos.CENTER);
        daycareBox.setPadding(new Insets(20));
        daycareBox.setStyle("-fx-background-color:#fcefdb;");

        Tab daycareTab = new Tab("Daycare", daycareBox);

        //boarding tab
        Label boardingHeader = new Label("Boarding");
        boardingHeader.setStyle("-fx-font-size:20px; -fx-font-weight:bold; -fx-text-fill: #748972;");

        ImageView catSleep = new ImageView();
        InputStream cs = ServicesController.class.getResourceAsStream("images/cat-sleeping.png");
        if (cs != null)
        {
            Image i = new Image(cs, 0, 200, true, true);
            catSleep.setImage(i);
            catSleep.setPreserveRatio(true);
        }
        Button catBoard = new Button("Cat Boarding");
        catBoard.setOnAction(e -> new BoardingController().showBoardingWindow("Cat"));
        VBox catBb = new VBox(8, new Label("Cat Boarding"), catSleep, catBoard);
        catBb.setAlignment(Pos.CENTER);

        ImageView dogSleep = new ImageView();
        InputStream ds = ServicesController.class.getResourceAsStream("images/dog-sleeping.png");
        if (ds != null)
        {
            Image i = new Image(ds, 0, 200, true, true);
            dogSleep.setImage(i);
            dogSleep.setPreserveRatio(true);
        }
        Button dogBoard = new Button("Dog Boarding");
        dogBoard.setOnAction(e -> new BoardingController().showBoardingWindow("Dog"));
        VBox dogBb = new VBox(8, new Label("Dog Boarding"), dogSleep, dogBoard);
        dogBb.setAlignment(Pos.CENTER);

        Button backB = new Button("Back");
        backB.setOnAction(e -> stage.close());

        HBox bContent = new HBox(40, catBb, dogBb);
        bContent.setAlignment(Pos.CENTER);
        VBox bBox = new VBox(10, boardingHeader, bContent, backB);
        bBox.setAlignment(Pos.CENTER);
        bBox.setPadding(new Insets(20));
        bBox.setStyle("-fx-background-color:#fcefdb;");  // match resort color

        Tab boardingTab = new Tab("Boarding", bBox);

        tabPane.getTabs().addAll(groomingTab, daycareTab, boardingTab);
        stage.setScene(new Scene(tabPane, 700, 800));
        stage.show();
    }
}
