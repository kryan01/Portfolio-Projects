package com.furseasonsresort.semesterproject;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.awt.*;
import java.net.URI;

public class SocialsController
{
    public static void showOtherPagesWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Follow Us");

    // buttons: socials - facebook, x, instagram
        Button facebook = new Button("Facebook"); facebook.setOnAction(e ->
            openInBrowser("www.facebook.com/profile.php?id=61575793450701"));
        facebook.setPadding(new Insets(20));
        Button x = new Button("X"); x.setOnAction(e ->
            openInBrowser("https://x.com/FurSeasonsPawsh"));
        x.setPadding(new Insets(20,30,20,30));
        Button instagram = new Button("Instagram");
        instagram.setOnAction(e ->
                openInBrowser("https://www.instagram.com/pawshirefurseasonsresort/"));
        instagram.setPadding(new Insets(20));

    // button: email
        Button emailButton = new Button("Email Us");
        emailButton.setOnAction(e -> {
            try {
                Desktop.getDesktop().mail(new URI("mailto:FurSeasons.Pawshire@gmail.com"));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        emailButton.setPadding(new Insets(10));

    // button: back/close
        Button back = new Button("Back"); back.setOnAction(e -> stage.close());

    // Vbox: contact - email, cancel, physical address
        VBox lowerButtons = new VBox(emailButton, back, FurSeasonsResort.getAddress());
        lowerButtons.setAlignment(Pos.CENTER);
        lowerButtons.setSpacing(30);
        lowerButtons.setPadding(new Insets(60));

    // VBox: socials and contact
        VBox box = new VBox(20, facebook, x, instagram, lowerButtons);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(20));
        box.setStyle("-fx-background-color:#fcefdb;");

        stage.setScene(new Scene(box, 400, 600));
        stage.show();
    }

// open url in native browser
    private static void openInBrowser(String url) {
        try {
            // launch the default browser
            Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}

