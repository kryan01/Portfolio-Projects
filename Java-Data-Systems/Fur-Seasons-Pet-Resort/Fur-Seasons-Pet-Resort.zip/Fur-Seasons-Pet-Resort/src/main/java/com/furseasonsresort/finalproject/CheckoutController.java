package com.furseasonsresort.semesterproject;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class CheckoutController
{
    public static void showCheckoutWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Checkout");

        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color:#fcefdb;");
        root.setAlignment(Pos.TOP_CENTER);

        // header
        Label header = new Label("Select a Payment Method");
        header.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");
        root.getChildren().add(header);

        // container for the card options
        VBox listBox = new VBox(10);
        listBox.setAlignment(Pos.TOP_LEFT);

        ObservableList<PaymentMethod> methods = UserManager.getPaymentMethods();
        ToggleGroup tg = new ToggleGroup();

        if (methods.isEmpty())
        {
            listBox.getChildren().add(new Label("No payment methods saved."));
        }

        else
        {
            for (PaymentMethod pm : methods)
            {
                //name in bold
                Label nameLbl = new Label(pm.getCardholderName());
                nameLbl.setStyle("-fx-font-weight:bold;");

                //  take last 4 digits of getCardNumber()
                String fullNum = pm.getCardNumber();
                String last4 = fullNum.length() >= 4 ? fullNum.substring(fullNum.length() - 4) : fullNum;
                Label numberLbl = new Label("**** " + last4);

                VBox cardBox = new VBox(4, nameLbl, numberLbl);
                cardBox.setPadding(new Insets(10));
                cardBox.setStyle("-fx-border-color:#cccccc; " + "-fx-border-radius:5; " + "-fx-background-color:white;"
                );

                RadioButton rb = new RadioButton();
                rb.setToggleGroup(tg);
                rb.setGraphic(cardBox);

                listBox.getChildren().add(rb);
            }
        }

        root.getChildren().add(listBox);

        //  buttons
        Button payBtn = new Button("Pay");
        Button addBtn = new Button("Add Payment Method");
        payBtn.setDisable(true);

        addBtn.setOnAction(e -> PaymentMethodController.showPaymentMethodWindow());
        payBtn.setOnAction(e ->
        {
            new Alert(Alert.AlertType.INFORMATION, "Payment successful!").showAndWait();
            stage.close();
        });

        tg.selectedToggleProperty().addListener((obs, old, nw) -> {
            payBtn.setDisable(nw == null);
        });
        // enable pay
        HBox btnBox = new HBox(10, payBtn, addBtn);
        btnBox.setAlignment(Pos.CENTER);
        root.getChildren().add(btnBox);

        stage.setScene(new Scene(root, 400, 350));
        stage.show();
    }
}
