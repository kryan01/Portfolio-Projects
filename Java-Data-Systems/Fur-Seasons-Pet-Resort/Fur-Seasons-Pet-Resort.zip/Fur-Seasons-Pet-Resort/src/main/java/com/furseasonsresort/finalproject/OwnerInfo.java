
package com.furseasonsresort.semesterproject;

public class OwnerInfo
{
    private final String firstName;
    private final String lastName;
    private final String phone;
    private final String email;
    private final String emergencyName;
    private final String emergencyPhone;

    public OwnerInfo(String firstName, String lastName, String phone, String email, String emergencyName, String emergencyPhone
    )
    {
        this.firstName      = firstName;
        this.lastName       = lastName;
        this.phone          = phone;
        this.email          = email;
        this.emergencyName  = emergencyName;
        this.emergencyPhone = emergencyPhone;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public String getPhone()
    {
        return phone;
    }
    public String getEmail()
    {
        return email;
    }
    public String getEmergencyName()
    {
        return emergencyName;
    }
    public String getEmergencyPhone()

    {

        return emergencyPhone;
    }
}
