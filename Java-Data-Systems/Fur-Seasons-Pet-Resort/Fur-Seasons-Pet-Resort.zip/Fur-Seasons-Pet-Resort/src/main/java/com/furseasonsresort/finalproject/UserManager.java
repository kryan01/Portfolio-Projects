package com.furseasonsresort.semesterproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    // username → password
    private static final Map<String, String> credentials = new HashMap<>();
    // username → owner info
    private static final Map<String, OwnerInfo> ownerMap = new HashMap<>();
    // username → pets list
    private static final Map<String, ObservableList<Pet>> petsMap = new HashMap<>();
    // username → payment methods
    private static final Map<String, ObservableList<PaymentMethod>> payMap = new HashMap<>();

    private static String currentUser = null;

    public static boolean register(String username, String password)
    {
        if (credentials.containsKey(username)) return false;
        credentials.put(username, password);
        ownerMap.put(username, null);
        petsMap.put(username, FXCollections.observableArrayList());
        payMap.put(username, FXCollections.observableArrayList());
        return true;
    }

    public static boolean login(String username, String password)
    {
        String stored = credentials.get(username);
        if (stored != null && stored.equals(password))
        {
            currentUser = username;
            return true;
        }
        return false;
    }

    public static boolean isLoggedIn()
    {
        return currentUser != null;
    }

    public static String getCurrentUser()
    {
        return currentUser;
    }

    public static void setCurrentUser(String username)
    {
        currentUser = username;
    }

    public static OwnerInfo getOwnerInfo(String username)
    {
        return ownerMap.get(username);
    }

    public static void setOwnerInfo(String username, OwnerInfo info)
    {
        ownerMap.put(username, info);
    }

    public static ObservableList<Pet> getPets()
    {
        return petsMap.getOrDefault(currentUser, FXCollections.observableArrayList());
    }

    public static ObservableList<PaymentMethod> getPaymentMethods()
    {
        return payMap.getOrDefault(currentUser, FXCollections.observableArrayList());
    }
}
