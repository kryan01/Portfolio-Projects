package com.furseasonsresort.semesterproject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class PaymentMethodController
{
    public static void showPaymentMethodWindow()
    {
        Stage stage = new Stage();
        stage.setTitle("Payment Method");

        Label header = new Label("Add Payment Method");
        header.setStyle("-fx-font-size:18px; -fx-font-weight:bold;");

        // payment type selector
        ToggleGroup typeGroup = new ToggleGroup();
        RadioButton cardRb = new RadioButton("Credit or debit card");
        cardRb.setToggleGroup(typeGroup);
        cardRb.setSelected(true);

        // form fields
        Label nameLbl = new Label("Cardholder name");
        TextField nameField = new TextField();
        nameField.setPromptText("Enter your name as it's written on the card");

        Label numberLbl = new Label("Card number");
        TextField numberField = new TextField();
        numberField.setPromptText("1234 1234 1234 1234");

        Label expLbl = new Label("Expiry date");
        TextField expField = new TextField();
        expField.setPromptText("MM / YY");

        Label secLbl = new Label("Security code");
        TextField secField = new TextField();
        secField.setPromptText("CVC");

        Label countryLbl = new Label("Country");
        ComboBox<String> countryBox = new ComboBox<>();
        countryBox.getItems().addAll("United States", "Canada", "United Kingdom", "Australia"
        );
        countryBox.setValue("United States");

        Button saveBtn = new Button("Save card");
        saveBtn.setOnAction(e ->
        {
            stage.close();
        });
        Button backBtn = new Button("Back");
        backBtn.setOnAction(e -> stage.close());

        HBox btnBox = new HBox(10, saveBtn, backBtn);
        btnBox.setAlignment(Pos.CENTER_RIGHT);

        // arrange  in GridPane
        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);
        form.setPadding(new Insets(20));
        form.add(cardRb,        0, 0, 2, 1);
        form.add(nameLbl,       0, 1);
        form.add(nameField,     1, 1);
        form.add(numberLbl,     0, 2);
        form.add(numberField,   1, 2);
        form.add(expLbl,        0, 3);
        form.add(expField,      1, 3);
        form.add(secLbl,        0, 4);
        form.add(secField,      1, 4);
        form.add(countryLbl,    0, 5);
        form.add(countryBox,    1, 5);
        form.add(btnBox,        1, 6);

        VBox root = new VBox(15, header, form);
        root.setAlignment(Pos.TOP_CENTER);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color:#fcefdb;");

        Scene scene = new Scene(root, 450, 500);
        stage.setScene(scene);
        stage.show();
    }
}
